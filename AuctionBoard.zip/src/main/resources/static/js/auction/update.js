/**
 * 
 */
$(document).ready(function() {
	$("#btnUpdate").click(function() {
		var formData = new FormData($("#updateForm")[0]);
		var subject = $("#updateSubject").val();
		var content = $("#updateContent").val();
		
		if (subject == "" || subject == null) {
			alert("제목을 입력해주세요.");
			return;
		}
		if (content == "" || content == null) {
			alert("세부 사항을 입력 해주세요.");
			return;
		}
		
		if ($("#auctionImg1").val() != "") {
			var ext = $('#auctionImg1').val().split('.').pop().toLowerCase();
			if ($.inArray(ext, ['png', 'jpg', 'jpeg' ]) == -1) {
				alert('사진만 업로드 할 수 있습니다.');
				return;
			}
		}		

		$.ajax({
			type : "post",
			url : $('#updateForm').attr('action'),
			data : formData,
			processData : false,
			contentType : false,
			success : function(response) {
				alert(response);
				location.href = "/board";
			},
			error : function(response) {
				alert(response.responseText);
			}
		});
	});
});