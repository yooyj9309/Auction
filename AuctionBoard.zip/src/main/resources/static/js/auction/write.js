$(document).ready(function() {
	$("#btnWrite").click(function() {
		var formData = new FormData($("#writeForm")[0]);
		var subject = $("#writeSubject").val();
		var content = $("#writeContent").val();
		var price = parseInt($("#writePrice").val());
		var period = parseInt($("#writePeriod").val());
		
		if (subject == "" || subject == null) {
			alert("제목을 입력해주세요.");
			return;
		}
		if (price == "" || price < 0) {
			alert("시작 가격을 확인해주세요.");
			return;
		}
		if(price > 10000){
			alert("시작 가격이 너무 높습니다.");
		}
		if (period == "" || period < 0 || period > 7) {
			alert("기간을 확인해주세요.");
			return;
		}
		
		if (content == "" || content == null) {
			alert("세부 사항을 입력 해주세요.");
			return;
		}
		
		$.ajax({
			type : "post",
			url : "boardwrite",
			data : formData,
			processData : false,
		    contentType : false,
			success : function(response) {
				alert(response);
				location.href = "/board";
			},
			error : function(response){
				alert(response.responseText);
			}
		});
	});
});
function onlyNumber(event){
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;
    if ( (keyID >= 48 && keyID <= 57) || (keyID >= 96 && keyID <= 105) || keyID == 8 || keyID == 46 || keyID == 37 || keyID == 39 ) 
        return;
    else
        return false;
}
 
function removeChar(event) {
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;
    if ( keyID == 8 || keyID == 46 || keyID == 37 || keyID == 39 ) 
        return;
    else
        event.target.value = event.target.value.replace(/[^0-9]/g, "");
}