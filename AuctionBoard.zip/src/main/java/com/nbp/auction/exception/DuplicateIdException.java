package com.nbp.auction.exception;

import org.springframework.dao.DuplicateKeyException;

public class DuplicateIdException extends DuplicateKeyException{
	
	public DuplicateIdException(String msg)
	{
		super(msg);
	}
}
