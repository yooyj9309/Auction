package com.nbp.auction.controller;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nbp.auction.domain.CategoryVO;
import com.nbp.auction.exception.InvalidInputException;
import com.nbp.auction.exception.NoAuthException;
import com.nbp.auction.exception.SQLErrorException;
import com.nbp.auction.service.BoardService;
import com.nbp.auction.service.SideService;

@RestController
@RequestMapping("/side")
public class SideController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BoardService.class);

	private static final int FAILCOIN = -1;
	private static final int MAX_COIN = 100000000;

	@Autowired
	private SideService sideService;

	/**
	 * 해당 user의 코인을 보여주는 함수
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	public ResponseEntity<Map<String, Object>> showSidebar(HttpSession session) {
		Map<String, Object> map = new HashMap<String, Object>();

		List<CategoryVO> categoryList = sideService.selectCategoryList();
		String userId = (String) session.getAttribute("userId");

		map.put("categoryList", categoryList);

		if (StringUtils.isEmpty(userId)) {
			map.put("userCoin", FAILCOIN);
		} else {
			int userCoin = sideService.selectUserCoin(userId);
			map.put("userCoin", userCoin);
		}

		return new ResponseEntity<Map<String, Object>>(map, HttpStatus.OK);
	}

	/**
	 * user의 코인을 update 하는 함수
	 * 
	 * @param session
	 * @param coin
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping(value = "", method = RequestMethod.POST)
	public ResponseEntity<Integer> updateCoin(HttpSession session, @RequestParam("coin") int coin) {
		LOGGER.info("입력 받은 코인의 양" + coin);	
		String userId = (String) session.getAttribute("userId");
		
		if(StringUtils.isEmpty(userId)) {
			throw new NoAuthException("충전하실 권한이 없습니다.");
		}
		
		int userCoin = sideService.selectUserCoin(userId);
		if(userCoin+coin>MAX_COIN) {
			throw new InvalidInputException("충전액이 너무 많습니다.");
		}
		sideService.updateUserCoin(userId, coin);
		
		return new ResponseEntity<Integer>(userCoin+coin,HttpStatus.OK);
	}
}
