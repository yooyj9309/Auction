package com.nbp.auction.controller;

import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.nbp.auction.domain.UserVO;
import com.nbp.auction.service.BoardService;
import com.nbp.auction.service.UserService;

@RestController
public class MemberController {
	private static final Logger LOGGER = LoggerFactory.getLogger(BoardService.class);

	@Autowired
	private UserService userService;

	/**
	 * 로그인 화면을 출력
	 * @return 로그인 화면 출력
	 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login() {
		ModelAndView loginView = new ModelAndView();
		loginView.setViewName("member/login");
		return loginView;
	}

	/**
	 * 로그인 로직을 수행하기 위한 함수
	 * @param loginInformation
	 * @param session
	 * @return 성공시 메시지 출력
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<String> login(@ModelAttribute("UserVO") UserVO loginInformation, HttpSession session) {
		UserVO user = userService.loginService(loginInformation);
		session.setAttribute("userId", user.getUserId());
		
		return new ResponseEntity<String>("로그인에 성공하셨습니다.", HttpStatus.OK);
	}

	/**
	 * 회원가입 로직 수행
	 * @param joinInformation
	 * @return 성공 시 메시지 출력
	 */
	@RequestMapping(value = "/join", method = RequestMethod.POST)
	public ResponseEntity<String> join(@ModelAttribute("UserVO") UserVO joinInformation) {
		LOGGER.info(joinInformation.toString());
		
		userService.joinService(joinInformation);
		
		LOGGER.info("JOIN SERVICE 로직 성공");
		return new ResponseEntity<String>("회원가입에 성공하셨습니다.", HttpStatus.OK);
	}

	/**
	 * 로그아웃 로직 수행 후 login 화면으로 redirect
	 * 
	 * @param session, sessionStatus
	 * @return logoutView
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView processLogout(HttpSession session,SessionStatus sessionStatus) {
		session.invalidate();
		sessionStatus.setComplete();
		
		ModelAndView logoutView = new ModelAndView();
		logoutView.setViewName("member/login");
		return logoutView;
	}
	
}