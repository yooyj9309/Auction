package com.nbp.auction.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nbp.auction.domain.ReplyVO;
import com.nbp.auction.service.BoardService;
import com.nbp.auction.service.ReplyService;
import com.nbp.auction.utils.ReplyPager;

@RestController
@RequestMapping("/reply")
public class ReplyController {

	@Autowired
	private ReplyService replyService;

	@RequestMapping(method = RequestMethod.POST)
	public void insertReply(@ModelAttribute ReplyVO reply, HttpSession session) {
		reply.setReplyWriter((String) session.getAttribute("userId"));
		replyService.insertReplyInfo(reply);
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView getReplyListView(@RequestParam int boardId, @RequestParam(defaultValue = "1") int curPage, ModelAndView mav) {

		int count = replyService.count(boardId);
		ReplyPager replyPager = new ReplyPager(count, curPage);

		int start = replyPager.getPageBegin();
		int end = replyPager.getPageEnd();

		List<ReplyVO> replyList = replyService.showReplyList(boardId, start, end);
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("replyList", replyList);
		map.put("replyPager", replyPager);
		mav.addObject("replyMap", map);
		mav.setViewName("reply/replyList");
		return mav;
	}

	@RequestMapping(value = "/detail/{replyId}", method = RequestMethod.GET)
	public ModelAndView getReplyDetailView(@PathVariable("replyId") Integer replyId, ModelAndView mav, HttpSession session) {
		ReplyVO vo = replyService.detail(replyId);
		mav.setViewName("reply/replyDetail");
		mav.addObject("vo", vo);
		return mav;
	}

	@RequestMapping(value = "/update/{replyId}", method = { RequestMethod.PUT, RequestMethod.PATCH })
	public ResponseEntity<String> replyUpdate(@PathVariable("replyId") Integer replyId, @RequestBody ReplyVO vo, HttpSession session) {
		vo.setReplyId(replyId);
		String userId = (String)session.getAttribute("userId");
		replyService.update(vo,userId);

		return new ResponseEntity<String>("success", HttpStatus.OK);
	}

	@RequestMapping(value = "/delete/{replyId}")
	public ResponseEntity<String> replyDelete(@PathVariable("replyId") Integer replyId, HttpSession session) {
		String userId = (String)session.getAttribute("userId");
		replyService.delete(replyId,userId);

		return new ResponseEntity<String>("success", HttpStatus.OK);
	}
	
}
