package com.nbp.auction.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.nbp.auction.domain.BoardVO;
import com.nbp.auction.domain.CategoryVO;
import com.nbp.auction.domain.ParamVO;
import com.nbp.auction.domain.TenderVO;
import com.nbp.auction.service.BoardService;
import com.nbp.auction.service.SideService;
import com.nbp.auction.service.TenderService;
import com.nbp.auction.utils.BoardPager;


@RestController
@RequestMapping("/board")
public class BoardController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BoardService.class);

	@Autowired
	private BoardService boardService;

	@Autowired
	private SideService sideService;

	/**
	 * 메인 화면을 출력하는 controller
	 * 
	 * @return MainBoardView
	 * @throws Exception
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	public ModelAndView getBoardListView(@ModelAttribute("ParamVO") ParamVO param) {
		boardService.updateStatus();
		ModelAndView mav = new ModelAndView();
		Map<String, Object> boardMap = new HashMap<String, Object>();

		int boardCount = boardService.getBoardCount(param);
		BoardPager pager = new BoardPager(boardCount, param.getCurPage());

		int startPage = pager.getPageBegin();
		int endPage = pager.getPageEnd();
		param.setStartPage(startPage);
		param.setEndPage(endPage);

		List<BoardVO> boardList = boardService.getBoardList(param);

		boardMap.put("list", boardList);
		boardMap.put("boardPager", pager);
		boardMap.put("startPage", startPage);
		boardMap.put("endPage", endPage);
		boardMap.put("contentCount", boardCount);
		boardMap.put("param", param);

		mav.addObject("boardMap", boardMap);
		mav.setViewName("board/boardList");
		return mav;
	}

	/**
	 * 게시판 상세
	 * 
	 * @param boardId
	 * @return 게시판 상세 view
	 * @throws Exception
	 */
	@RequestMapping(value = "/{boardId}", method = RequestMethod.GET)
	public ModelAndView getBoardDetailView(@ModelAttribute("ParamVO") ParamVO param,
			@PathVariable("boardId") int boardId, HttpSession session) {

		ModelAndView mav = new ModelAndView();
		Map<String, Object> boardMap = new HashMap<String, Object>();

		BoardVO boardInfo = boardService.getBoardInfoById(boardId);
		TenderVO tender = new TenderVO();
		String userId = (String) session.getAttribute("userId");
		tender.setBoardId(boardId);
		tender.setUserId(userId);

		int tenderPrice = 0;

		if (!StringUtils.isEmpty(userId) && boardService.isAlreadyParticipate(tender)) {
			tenderPrice = boardService.getTenderPrice(tender);
		}

		boardMap.put("board", boardInfo);
		boardMap.put("tenderPrice", tenderPrice);

		mav.setViewName("board/boardView");
		mav.addObject("boardMap", boardMap);

		return mav;
	}

	/**
	 * 게시판 등록하는 화면 출력
	 * 
	 * @return BoardWriteView
	 * @throws Exception
	 */
	@RequestMapping(value = "/boardwrite", method = RequestMethod.GET)
	public ModelAndView getBoardWriteView() throws Exception {
		ModelAndView mav = new ModelAndView();
		List<CategoryVO> categoryList = sideService.selectCategoryList();
		Map<String, Object> paramMap = new HashMap<String, Object>();

		paramMap.put("categoryList", categoryList);
		mav.addObject("paramMap", paramMap);
		mav.setViewName("/board/boardWrite");
		return mav;
	}
	/**
	 * update화면 출력
	 * 
	 * @param boardId
	 * @return updateView 출력
	 * @throws Exception
	 */
	@RequestMapping(value = "/boardwrite/{boardId}", method = RequestMethod.GET)
	public ModelAndView getBoardUpdateView(@PathVariable("boardId") int boardId) throws Exception {
		ModelAndView mav = new ModelAndView();
		BoardVO board = boardService.selectBoardByBoardId(boardId);
		List<CategoryVO> categoryList = sideService.selectCategoryList();

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("categoryList", categoryList);
		paramMap.put("board", board);

		mav.addObject("paramMap", paramMap);
		mav.setViewName("/board/boardUpdate");

		return mav;
	}
	
	@RequestMapping(value = "/mypage", method = RequestMethod.GET)
	public ModelAndView showMyPageList(HttpSession session, ModelAndView mav) {
		String userId = (String) session.getAttribute("userId");
		Map<String, Object> map = new HashMap<String, Object>();

		List<TenderVO>[] resultList = boardService.selectParticipateList(userId);
		List<TenderVO> participateList = resultList[0];
		List<TenderVO> successList = resultList[1];

		map.put("participateList", participateList);
		map.put("successList", successList);

		mav.addObject("myPageMap", map);
		mav.setViewName("board/mypage");
		return mav;
	}
	
	@RequestMapping(value = "/boardwrite", method = RequestMethod.POST)
	public ResponseEntity<String> registerBoard(@ModelAttribute("BoardVO") BoardVO boardInformation,
			HttpSession session) {
		LOGGER.info(boardInformation.toString());
		String userId = (String) session.getAttribute("userId");
		boardInformation.setUserId(userId);
		boardInformation = boardService.registerBoardService(boardInformation, session);

		return new ResponseEntity<String>("게시물 등록에 성공하셨습니다.", HttpStatus.OK);
	}



	/**
	 * update 로직 수행후 redirect
	 * 
	 * @param board
	 * @param boardId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/boardwrite/{boardId}", method = RequestMethod.POST)
	public ResponseEntity<String> updateBoard(@ModelAttribute("BoardVO") BoardVO boardInformation,
			@PathVariable("boardId") int boardId, HttpSession session) throws Exception {
		LOGGER.info(boardInformation.toString() + " " + boardId);
		String userId = (String) session.getAttribute("userId");
		boardInformation.setUserId(userId);
		boardService.updateBoardService(boardInformation, session);
		return new ResponseEntity<String>("업데이트에 성공하셨습니다.", HttpStatus.OK);
	}

	/**
	 * 게시판 삭제 로직 수행후 redirect
	 * 
	 * @param boardId
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/{boardId}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteBoard(@PathVariable("boardId") int boardId) {
		boardService.deleteBoardService(boardId);
		return new ResponseEntity<String>("거래가 종료되었습니다.", HttpStatus.OK);
	}

	@RequestMapping(value = "/tender", method = RequestMethod.POST)
	public ResponseEntity<Map<String, Object>> tenderBoard(@ModelAttribute("TenderVO") TenderVO tender,
			HttpSession session) {
		Map<String, Object> map = new HashMap<String, Object>();

		String userId = (String) session.getAttribute("userId");
		tender.setUserId(userId);
		int userCoin = boardService.tenderService(tender);
		int tenderPrice = tender.getTenderPrice();

		map.put("tenderPrice", tenderPrice);
		map.put("userCoin", userCoin);

		return new ResponseEntity<Map<String, Object>>(map, HttpStatus.OK);
	}

	

}