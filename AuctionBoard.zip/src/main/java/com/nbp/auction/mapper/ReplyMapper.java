package com.nbp.auction.mapper;

import java.util.List;
import java.util.Map;

import com.nbp.auction.domain.ReplyVO;

public interface ReplyMapper {

	void insertReplyInfo(ReplyVO reply);

	int count(int boardId);

	List<ReplyVO> selectReplyList(Map<String, Object> map);

	ReplyVO detailReply(Integer replyId);

	void updateReply(ReplyVO vo);

	void deleteReply(Integer replyId);
}
