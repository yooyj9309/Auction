package com.nbp.auction.mapper;

import java.util.List;
import java.util.Map;

import com.nbp.auction.domain.CategoryVO;

public interface SideMapper {

	List<CategoryVO> selectCategoryList();

	int selectUserCoin(String userId);

	void updateUserCoin(Map<String, Object> paramMap);
}
