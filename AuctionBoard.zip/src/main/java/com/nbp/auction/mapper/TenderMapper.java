package com.nbp.auction.mapper;

import java.util.List;
import java.util.Map;

import com.nbp.auction.domain.TenderVO;

public interface TenderMapper {

	/**
	 * 현재 유저가 가지고 있는 코인의 양
	 * 
	 * @param participant
	 * @return
	 */
	int getUserCoin(String participant);

	/**
	 * 변경된 유저의 코인을 업데이트
	 * 
	 * @param map
	 */
	void updateUserCoin(Map<String, Object> map);

	/**
	 * 경매 정보 입력
	 * 
	 * @param map
	 */
	void insertTenderInfo(TenderVO tender);

	/**
	 * 해당 유저가 참가했는 지 확인하는 함수
	 * 
	 * @param tender
	 * @return
	 */
	int selectParticipate(TenderVO tender);

	/**
	 * 현재 유저가 입찰한 코인의 양
	 * 
	 * @param tender
	 * @return
	 */
	int selectTenderPrice(TenderVO tender);

	/**
	 * 경매 정보 경신
	 * 
	 * @param tender
	 */
	void updateTenderInfo(TenderVO tender);

	List<TenderVO> selectTenderListByUserId(String userId);

	List<TenderVO> selectTenderInfoById(int boardId);

	List<TenderVO> selectHighestTenderList(int boardId);

	List<TenderVO> selectFinishAuction();

	List<TenderVO> selectWinnerList();

}
