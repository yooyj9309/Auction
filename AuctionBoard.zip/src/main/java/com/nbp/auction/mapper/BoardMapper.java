package com.nbp.auction.mapper;

import java.util.List;
import java.util.Map;

import com.nbp.auction.domain.BoardVO;
import com.nbp.auction.domain.ParamVO;

public interface BoardMapper {

	void insertBoardInformation(BoardVO board);

	List<BoardVO> selectBoardList(ParamVO param);

	int countBoard(ParamVO param);

	BoardVO selectBoardByBoardId(int boardId);

	void updateHitNumber(int boardId);

	void updateBoardInformation(BoardVO vo);

	void deleteBoard(int boardId);

	List<BoardVO> selectBoardByCategory(String categoryName);

	void updateStatus();

	String selectImagePath(int boardId);
}