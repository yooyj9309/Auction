package com.nbp.auction.mapper;

import com.nbp.auction.domain.UserVO;

public interface UserMapper {

	void insertNewUserInformation(UserVO userInformation);

	String selectCheckInformation(UserVO loginInformation);
	
	String selectIdCheck(UserVO loginInformation);
	
	UserVO selectMyInfo(String userId);
}
