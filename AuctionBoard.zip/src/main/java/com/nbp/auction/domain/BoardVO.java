package com.nbp.auction.domain;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class BoardVO {

	private int boardId;
	private int viewCnt;
	private int startingPrice;
	private int categoryId;
	private int status;
	private int period;

	private String subject;
	private String content;
	private String userId;
	private String categoryName;
	private String imgPath;

	private Date regDate;
	private Date endDate;

	private MultipartFile imgFile;

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	public MultipartFile getImgFile() {
		return imgFile;
	}

	public void setImgFile(MultipartFile imgFile) {
		this.imgFile = imgFile;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	private int replyCount;

	public int getReplyCount() {
		return replyCount;
	}

	public void setReplyCount(int replyCount) {
		this.replyCount = replyCount;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getViewCnt() {
		return viewCnt;
	}

	public void setViewCnt(int viewCnt) {
		this.viewCnt = viewCnt;
	}

	public int getStartingPrice() {
		return startingPrice;
	}

	public void setStartingPrice(int startingPrice) {
		this.startingPrice = startingPrice;
	}

	public int getBoardId() {
		return boardId;
	}

	public void setBoardId(int boardId) {
		this.boardId = boardId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "BoardVO [boardId=" + boardId + ", viewCnt=" + viewCnt + ", startingPrice=" + startingPrice
				+ ", categoryId=" + categoryId + ", status=" + status + ", period=" + period + ", subject=" + subject
				+ ", content=" + content + ", userId=" + userId + ", categoryName=" + categoryName + ", imgPath="
				+ imgPath + ", regDate=" + regDate + ", endDate=" + endDate + ", imgFile=" + imgFile + ", replyCount="
				+ replyCount + "]";
	}

	

}