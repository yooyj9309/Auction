package com.nbp.auction.domain;

public class TenderVO {

	private String userId;
	private int boardId;
	private int tenderPrice;
	private String writer;
	private int status = 2;// 0: 입찰 실패, 1: 입찰 성공, 2: 대기중
	private String subject;
	private int startingPrice;

	public int getStartingPrice() {
		return startingPrice;
	}

	public void setStartingPrice(int startingPrice) {
		this.startingPrice = startingPrice;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public int getTenderPrice() {
		return tenderPrice;
	}

	public void setTenderPrice(int tenderPrice) {
		this.tenderPrice = tenderPrice;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getBoardId() {
		return boardId;
	}

	public void setBoardId(int boardId) {
		this.boardId = boardId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + boardId;
		result = prime * result + status;
		result = prime * result + tenderPrice;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((writer == null) ? 0 : writer.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TenderVO other = (TenderVO) obj;
		if (boardId != other.boardId)
			return false;
		if (status != other.status)
			return false;
		if (tenderPrice != other.tenderPrice)
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		if (writer == null) {
			if (other.writer != null)
				return false;
		} else if (!writer.equals(other.writer))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "TenderVO [userId=" + userId + ", boardId=" + boardId + ", tenderPrice=" + tenderPrice + ", writer="
				+ writer + ", status=" + status + "]";
	}

}
