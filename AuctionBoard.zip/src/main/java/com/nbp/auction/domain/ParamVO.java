package com.nbp.auction.domain;

public class ParamVO {
	private String searchCondition = "";
	private String sortCondition = "regDate";
	private int category = 0;
	private String keyword = "";
	private int curPage = 1;
	private int startPage = 1;
	private int endPage = 1;
	private String userId = "";
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public String getSearchCondition() {
		return searchCondition.trim();
	}

	public void setSearchCondition(String searchCondition) {
		this.searchCondition = searchCondition;
	}

	public String getSortCondition() {
		return sortCondition.trim();
	}

	public void setSortCondition(String sortCondition) {
		this.sortCondition = sortCondition;
	}

	public String getKeyword() {
		return keyword.trim();
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getCurPage() {
		return curPage;
	}

	public void setCurPage(int curPage) {
		this.curPage = curPage;
	}

	@Override
	public String toString() {
		return "ParamVO [searchCondition=" + searchCondition + ", sortCondition=" + sortCondition + ", category="
				+ category + ", keyword=" + keyword + ", curPage=" + curPage + "]";
	}

}
