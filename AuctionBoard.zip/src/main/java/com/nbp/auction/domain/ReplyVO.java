package com.nbp.auction.domain;

import java.util.Date;

public class ReplyVO {
	private Integer replyId;
	private Integer boardId;
	private String replyText;
	private String replyWriter;
	private Date regDate;
	private Date updateDate;
	private String poster;

	public String getPoster() {
		return poster;
	}

	public void setPoster(String poster) {
		this.poster = poster;
	}

	public String getReplyText() {
		return replyText;
	}

	public void setReplyText(String replyText) {
		this.replyText = replyText;
	}

	public Integer getReplyId() {
		return replyId;
	}

	public void setReplyId(Integer replyId) {
		this.replyId = replyId;
	}

	public Integer getBoardId() {
		return boardId;
	}

	public void setBoardId(Integer boardId) {
		this.boardId = boardId;
	}

	public String getReplyWriter() {
		return replyWriter;
	}

	public void setReplyWriter(String replyWriter) {
		this.replyWriter = replyWriter;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String value = "rid " + replyId + " \n" + "bid " + boardId + " \n" + "rText " + replyText + " \n" + "rWriter "
				+ replyWriter + " \n" + "rDate " + regDate + " \n" + "rUpdateDate " + updateDate + " \n";
		return value;
	}

}
