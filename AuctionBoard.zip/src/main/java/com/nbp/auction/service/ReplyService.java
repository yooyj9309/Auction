package com.nbp.auction.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.nbp.auction.domain.ReplyVO;
import com.nbp.auction.exception.InvalidInputException;
import com.nbp.auction.exception.NoAuthException;
import com.nbp.auction.exception.ServerErrorException;
import com.nbp.auction.mapper.ReplyMapper;

@Service("com.nbp.auction.service.ReplyService")
public class ReplyService {

	@Autowired
	private ReplyMapper replyMapper;

	public void insertReplyInfo(ReplyVO reply) {
		if(StringUtils.isEmpty(reply.getReplyWriter())) {
			throw new NoAuthException("댓글을 쓰실 권한이 없으십니다.");
		}
		if(StringUtils.isEmpty(reply.getReplyText())) {
			throw new InvalidInputException("댓글을 입력해주세요.");
		}
		if(reply.getReplyText().length() > 1000) {
			throw new InvalidInputException("너무 긴 댓글입니다.");
		}
		try {
			replyMapper.insertReplyInfo(reply);
		} catch (DataAccessException e) {
			throw new ServerErrorException("댓글 입력 오류입니다.");
		}
	}

	public List<ReplyVO> showReplyList(int boardId, int start, int end) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("boardId", boardId);
		map.put("start", start);
		map.put("end", end);

		List<ReplyVO> replyList = null;
		try {
			replyList = replyMapper.selectReplyList(map);
		} catch (DataAccessException e) {
			throw new ServerErrorException("댓글 리스트를 불러오기 실패");
		}
		return replyList;
	}

	public ReplyVO detail(Integer replyId) {
		ReplyVO vo = null;
		try {
			vo = replyMapper.detailReply(replyId);
		} catch (DataAccessException e) {
			throw new ServerErrorException("댓글 상세보기 실패");
		}
		return vo;
	}

	public void update(ReplyVO reply,String userId) {
		
		if(StringUtils.isEmpty(reply.getReplyText())) {
			throw new InvalidInputException("댓글을 입력해주세요.");
		}
		if(reply.getReplyText().length() > 1000) {
			throw new InvalidInputException("너무 긴 댓글입니다.");
		}
		try {
			replyMapper.updateReply(reply);
		} catch (DataAccessException e) {
			throw new ServerErrorException("댓글 업데이트 실패");
		}

	}

	public void delete(Integer replyId, String userId) {
		
		try {
			replyMapper.deleteReply(replyId);
		} catch (DataAccessException e) {
			throw new ServerErrorException("댓글 삭제 실패");
		}

	}

	public int count(int boardId) {
		int cnt = 0;
		try {
			cnt = replyMapper.count(boardId);
		} catch (DataAccessException e) {
			throw new ServerErrorException("댓글 수 가져오기 실패");
		}
		return cnt;
	}
	
}
