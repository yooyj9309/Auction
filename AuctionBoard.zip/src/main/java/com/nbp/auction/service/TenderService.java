package com.nbp.auction.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbp.auction.domain.TenderVO;
import com.nbp.auction.exception.SQLErrorException;
import com.nbp.auction.mapper.BoardMapper;
import com.nbp.auction.mapper.TenderMapper;

@Service("com.nbp.auction.service.TenderService")
public class TenderService {
	private static final Logger LOGGER = LoggerFactory.getLogger(BoardService.class);

	@Autowired
	BoardMapper boardMapper;
	@Autowired
	TenderMapper tenderMapper;

	@Transactional
	public void finishAuction() {
		try {
			boardMapper.updateStatus();
			List<TenderVO> endAuctionList = tenderMapper.selectFinishAuction();

			if (!endAuctionList.isEmpty()) {
				List<TenderVO> winnerList = tenderMapper.selectWinnerList();
				getBackMoney(endAuctionList, winnerList);
				settleMoney(winnerList);
			}
		} catch (DataAccessException e) {
			throw new SQLErrorException("서버 에러입니다.");
		}
	}

	@Transactional
	private void settleMoney(List<TenderVO> winnerList) {
		Map<String, Integer> account = new HashMap<String, Integer>();

		for (TenderVO tender : winnerList) {
			if (account.containsKey(tender.getWriter())) {
				int updatePrice = account.get(tender.getWriter()) + tender.getTenderPrice();
				account.put(tender.getWriter(), updatePrice);
			} else {
				account.put(tender.getWriter(), tender.getTenderPrice());
			}
			tender.setStatus(1);
			try {
				tenderMapper.updateTenderInfo(tender);
			} catch (DataAccessException e) {
				throw new SQLErrorException("서버 에러입니다.");
			}
		}
		updateCoin(account);
	}

	@Transactional
	private void getBackMoney(List<TenderVO> endAuctionList, List<TenderVO> winnerList) // 낙찰에 실패한 사람들이 돈을 돌려 받는 함수
	{
		HashSet<TenderVO> otherSet = new HashSet<TenderVO>();
		Map<String, Integer> otherMap = new HashMap<String, Integer>();

		for (TenderVO winner : winnerList) {
			otherSet.add(winner);
		}
		for (TenderVO others : endAuctionList) {
			if (otherSet.contains(others)) {
				otherSet.remove(others);
			} else {
				otherMap.put(others.getUserId(), others.getTenderPrice());
			}
			others.setStatus(0);
			try {
				tenderMapper.updateTenderInfo(others);
			} catch (DataAccessException e) {
				throw new SQLErrorException("서버 에러입니다.");
			}
		}
		updateCoin(otherMap);
	}

	@Transactional
	private void updateCoin(Map<String, Integer> account) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		for (String userId : account.keySet()) {
			paramMap.put("userId", userId);
			paramMap.put("updateCoin", account.get(userId));
			try {
				tenderMapper.updateUserCoin(paramMap);
			} catch (DataAccessException e) {
				throw new SQLErrorException("서버 에러입니다.");
			}
		}
	}
}
