package com.nbp.auction.service;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.nbp.auction.domain.BoardVO;
import com.nbp.auction.domain.ParamVO;
import com.nbp.auction.domain.TenderVO;
import com.nbp.auction.exception.InputValueNullException;
import com.nbp.auction.exception.InvalidInputException;
import com.nbp.auction.exception.NoAuthException;
import com.nbp.auction.exception.SQLErrorException;
import com.nbp.auction.exception.ServerErrorException;
import com.nbp.auction.mapper.BoardMapper;
import com.nbp.auction.mapper.TenderMapper;
import com.nbp.auction.utils.ImgUtil;
import com.nbp.auction.utils.TimeUtil;

@Service("com.nbp.auction.service.BoardService")
public class BoardService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BoardService.class);

	private static final int AUCTION_SUCCESS = 1;
	private static final int AUCTION_FAIL = 0;
	private static final int AUCTION_ING = 2;

	@Autowired
	private BoardMapper boardMapper;

	@Autowired
	private TenderMapper tenderMapper;

	/**
	 * param 안의 조건들이 적용 된 경매 리스트들을 가져오는 함수
	 * 
	 * @param param
	 * @return 경매 리스트
	 */
	public List<BoardVO> getBoardList(ParamVO param) {
		List<BoardVO> boardList = null;
		try {
			boardList = boardMapper.selectBoardList(param);
		} catch (DataAccessException e) {
			throw new ServerErrorException("서버 에러 입니다.");
		}
		return boardList;
	}

	/**
	 * param의 조건들이 적용된 경매 게시 글의 수가 몇개 인지
	 * 
	 * @param param
	 * @return 경매 게시 수
	 */
	public int getBoardCount(ParamVO param) {
		int result = 0;
		try {
			result = boardMapper.countBoard(param);
		} catch (DataAccessException e) {
			throw new ServerErrorException("서버 에러입니다.");
		}
		return result;
	}

	/**
	 * 해당 경매에서 사용자가 얼마를 걸었는 지 확인 하는 함수
	 * 
	 * @param tender
	 * @return 사용자가 입찰한 가격
	 */
	public int getTenderPrice(TenderVO tender) {
		int tenderPrice = 0;
		try {
			tenderPrice = tenderMapper.selectTenderPrice(tender);
		} catch (DataAccessException e) {
			throw new ServerErrorException("서버 에러입니다.");
		}
		return tenderPrice;
	}

	/**
	 * 해당 게시글에 관한 정보 가져오는 함수
	 * 
	 * @param boardId
	 * @return 게시글 ID에 해당하는 정보
	 */
	public BoardVO getBoardInfoById(int boardId) {
		BoardVO boardInfo = null;
		try {
			boardInfo = boardMapper.selectBoardByBoardId(boardId);
		} catch (DataAccessException e) {
			throw new ServerErrorException("서버 에러입니다.");
		}
		return boardInfo;
	}

	public BoardVO registerBoardService(BoardVO boardInformation, HttpSession session) {
		String content = boardInformation.getContent();
		String subject = boardInformation.getSubject();
		String savePath = "images";
		String writer = boardInformation.getUserId();
		String fileName = boardInformation.getImgFile().getOriginalFilename();

		int price = boardInformation.getStartingPrice();
		int period = boardInformation.getPeriod();

		if (StringUtils.isEmpty(writer)) {
			throw new NoAuthException("권한이 없습니다.");
		}
		if (StringUtils.isEmpty(subject)) {
			throw new InvalidInputException("제목을 적어주세요.");
		}
		if (StringUtils.isEmpty(content)) {
			throw new InvalidInputException("세부사항을 입력해주세요.");
		}
		if (price < 0) {
			throw new InvalidInputException("시작 가격이 너무 낮습니다.");
		}
		if(price > 10000) {
			throw new InvalidInputException("시작 가격이 너무 높습니다.");
		}
		if (period < 0 || period > 7) {
			throw new InvalidInputException("기간을 확인해주세요.");
		}
		if (!isPhotoFile(fileName)) {
			throw new InvalidInputException("사진만 입력해주세요.");
		}
		if (content.length() > 3000) {
			throw new InvalidInputException("너무 긴 세부사항입니다.");
		}
		if (subject.length() > 1000) {
			throw new InvalidInputException("너무 긴 제목입니다.");
		}

		Date endDate = TimeUtil.getTime(period);
		String imgPath = ImgUtil.imgUpload(savePath, session, boardInformation.getImgFile(),
				boardInformation.getImgPath());

		boardInformation.setEndDate(endDate);
		boardInformation.setStatus(TimeUtil.getPeriod(boardInformation.getEndDate()));
		boardInformation.setImgPath(imgPath);

		try {
			boardMapper.insertBoardInformation(boardInformation);
		} catch (DataAccessException e) {
			deletePhoto(imgPath);
			throw new SQLErrorException("서버 에러 입니다. insert");
		}
		return boardInformation;
	}

	private void deletePhoto(String filePath) {
		File file = new File(filePath);
		if (file.exists()) {
			if (file.delete()) {
				LOGGER.info(filePath + "삭제 성공");
			} else {
				LOGGER.info(filePath + "삭제 성공");
			}
		} else {
			LOGGER.info(filePath + "가 존재하지 않습니다.");
		}
	}

	private boolean isPhotoFile(String str) {
		String allowPattern = ".+\\.(jpg|png|JPG|PNG)$";
		boolean result = false;

		Pattern p = Pattern.compile(allowPattern);
		Matcher m = p.matcher(str);
		result = m.matches();

		if (StringUtils.isEmpty(str))
			result = true;
		return result;
	}

	@Transactional
	public void updateBoardService(BoardVO boardInformation, HttpSession session) throws Exception {
		String content = boardInformation.getContent();
		String subject = boardInformation.getSubject();
		String savePath = "images";
		String writer = boardInformation.getUserId();
		String fileName = boardInformation.getImgFile().getOriginalFilename();

		if (StringUtils.isEmpty(writer)) {
			throw new NoAuthException("권한이 없습니다.");
		}
		if (StringUtils.isEmpty(subject)) {
			throw new InvalidInputException("제목을 적어주세요.");
		}
		if (StringUtils.isEmpty(content)) {
			throw new InvalidInputException("세부사항을 입력해주세요.");
		}
		if (!isPhotoFile(fileName)) {
			throw new InvalidInputException("사진만 입력해주세요.");
		}
		if (content.length() > 3000) {
			throw new InvalidInputException("너무 긴 세부사항입니다.");
		}
		if (subject.length() > 1000) {
			throw new InvalidInputException("너무 긴 제목입니다.");
		}
		String imgPath = null;
		if (StringUtils.isEmpty(fileName)) {
			try {
				imgPath = boardMapper.selectImagePath(boardInformation.getBoardId());
			} catch (DataAccessException e) {
				throw new ServerErrorException("서버 오류 입니다.");
			}
		} else {
			imgPath = ImgUtil.imgUpload(savePath, session, boardInformation.getImgFile(),
					boardInformation.getImgPath());
		}
		boardInformation.setImgFile(boardInformation.getImgFile());
		boardInformation.setImgPath(imgPath);
		boardMapper.updateBoardInformation(boardInformation);
	}

	public BoardVO selectBoardByBoardId(int boardId) {
		BoardVO board = null;
		try {
			board = boardMapper.selectBoardByBoardId(boardId);
		} catch (DataAccessException e) {
			throw new SQLErrorException("서버 에러입니다.");
		}
		return board;
	}

	@Transactional(rollbackFor = { Exception.class })
	public void deleteBoardService(int boardId) {
		List<TenderVO> tenderList = getTenderListById(boardId);
		Map<String, Object> paramMap = new HashMap<String, Object>();
		if (tenderList.size() > 0) {
			List<TenderVO> highestTenderList = getHighestTenderListById(boardId);
			String bidder = getBidder(highestTenderList);

			for (TenderVO tender : tenderList) {
				if (tender.getUserId().equals(bidder)) {
					int highestTender = tender.getTenderPrice();
					String auctionWriter = tender.getWriter();

					paramMap.put("userId", auctionWriter);
					paramMap.put("updateCoin", highestTender);
					tender.setStatus(AUCTION_SUCCESS);

					LOGGER.info(bidder + " -> " + auctionWriter + " : " + highestTender);
				} else { // 입찰에 실패한 사람들
					paramMap.put("userId", tender.getUserId());
					paramMap.put("updateCoin", tender.getTenderPrice());
					tender.setStatus(AUCTION_FAIL);

					LOGGER.info(tender.getUserId() + " 반환 " + " : " + tender.getTenderPrice());
				}
				try {
					tenderMapper.updateUserCoin(paramMap);
					tenderMapper.updateTenderInfo(tender);
				} catch (DataAccessException e) {
					throw new SQLErrorException("삭제 도중 문제가 발생했습니다.");
				}
			}
		}
		try {
			boardMapper.deleteBoard(boardId);
		} catch (DataAccessException e) {
			throw new SQLErrorException("삭제 도중 문제가 발생했습니다.");
		}

	}

	private List<TenderVO> getHighestTenderListById(int boardId) {
		List<TenderVO> tenderList = null;
		try {
			tenderList = tenderMapper.selectHighestTenderList(boardId);
		} catch (DataAccessException e) {
			throw new SQLErrorException("경매리스트를 호출 중 문제 발생");
		}
		return tenderList;
	}

	private List<TenderVO> getTenderListById(int boardId) {
		List<TenderVO> tenderList = null;
		try {
			tenderList = tenderMapper.selectTenderInfoById(boardId);
		} catch (DataAccessException e) {
			throw new SQLErrorException("경매리스트를 호출 중 문제 발생");
		}
		return tenderList;
	}

	private String getBidder(List<TenderVO> highestTenderList) {
		int size = highestTenderList.size();
		int randNum = (int) (Math.random() * size);

		return highestTenderList.get(randNum).getUserId();
	}

	public List<TenderVO>[] selectParticipateList(String userId) {
		if (StringUtils.isEmpty(userId)) {
			throw new NoAuthException("내역을 보실 권한이 없습니다.");
		}
		List<TenderVO>[] returnList = new List[2];
		for (int i = 0; i < 2; i++) {
			returnList[i] = new ArrayList<TenderVO>();
		}
		List<TenderVO> allTenderList = null;
		try {
			allTenderList = tenderMapper.selectTenderListByUserId(userId);
		} catch (DataAccessException e) {
			throw new SQLErrorException("서버 문제 발생");
		}
		for (TenderVO tender : allTenderList) {
			if (tender.getStatus() == AUCTION_ING) // 진행중인 것은 0번에
			{
				returnList[0].add(tender);
			} else if (tender.getStatus() == AUCTION_SUCCESS) // 성공한것은 1번에
			{
				returnList[1].add(tender);
			}
		}
		return returnList;
	}

	/**
	 * 입찰 메인 알고리즘 입찰가를 자신의 마음대로 올릴 수 있는 경매 입찰 방식 처음 참여한 경우 insert 이전에 참여를 하고 수정하는
	 * 경우: 업데이트 된 나의 코인 = 이전에 걸었던 경매 입찰가 + 현재 나의 코인 - 지금 걸었던 입찰가
	 * 
	 * @param tender
	 * @param session
	 * @return
	 * @throws SQLException
	 * @throws InputValueNullException
	 */
	@Transactional(rollbackFor = { Exception.class })
	public int tenderService(TenderVO tender) {
		Map<String, Object> paramMap = new HashMap<String, Object>();

		String userId = tender.getUserId();
		String writer = tender.getWriter();

		int tenderPrice = tender.getTenderPrice();
		int startingPrice = tender.getStartingPrice();
		int updateCoin = 0;
		int userCoin = 0;

		if (StringUtils.isEmpty(userId)) {
			throw new NoAuthException("입찰하실 권한이 없습니다.");
		}
		if (userId.equals(tender.getWriter())) {
			throw new NoAuthException("본인의 경매에 입찰할 수 없습니다.");
		}
		if (StringUtils.isEmpty(writer)) {
			throw new NoAuthException("잘못된 경매 게시글입니다.");
		}
		if (tenderPrice <= 0) {
			throw new InvalidInputException("입찰 하실 수 없는 금액입니다.");
		}
		if (startingPrice > tenderPrice) {
			throw new InvalidInputException("시작 가격보다 높게 입찰해주세요.");
		}
		if (tender.getStatus() != 2) {
			throw new NoAuthException("이미 끝난 경매입니다.");
		}
		try {
			userCoin = tenderMapper.getUserCoin(userId);
		} catch (DataAccessException e) {
			throw new SQLErrorException("코인을 불어오는 도중 에러 발생");
		}

		int result = 0;

		paramMap.put("userId", userId);
		paramMap.put("boardId", tender.getBoardId());

		if (isAlreadyParticipate(tender)) {
			int pastTender = 0;

			try {
				pastTender = tenderMapper.selectTenderPrice(tender); // 과거에 걸었던 입찰가
			} catch (DataAccessException e) {
				throw new SQLErrorException("입찰가를 불러오던 도중 에러 발생");
			}
			if (pastTender + userCoin < tenderPrice) {
				throw new InvalidInputException("충전이 필요합니다.");
			}
			updateCoin = pastTender - tenderPrice;
			tender.setStatus(AUCTION_ING);
			try {
				tenderMapper.updateTenderInfo(tender);
			} catch (DataAccessException e) {
				throw new SQLErrorException("경매정보 업데이트 중 에러 발생");
			}
		} else {
			if (userCoin < tenderPrice) {
				throw new InvalidInputException("충전이 필요합니다.");
			}
			updateCoin = -tenderPrice;
			try {
				tenderMapper.insertTenderInfo(tender);
			} catch (DataAccessException e) {
				throw new SQLErrorException("경매정보 입력 중 에러 발생");
			}
		}
		paramMap.put("updateCoin", updateCoin);
		try {
			tenderMapper.updateUserCoin(paramMap);
			result = tenderMapper.getUserCoin(userId);
		} catch (DataAccessException e) {
			throw new SQLErrorException("업데이트 중 에러발생");
		}
		return result;

	}

	public void updateStatus() {
		boardMapper.updateStatus();
	}

	public boolean isAlreadyParticipate(TenderVO tender) {
		int participate = 0;
		try {
			participate = tenderMapper.selectParticipate(tender);
		} catch (DataAccessException e) {
			throw new SQLErrorException("서버 에러가 발생하였습니다.");
		}
		return (participate != 0) ? true : false;
	}

}