package com.nbp.auction.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.nbp.auction.domain.CategoryVO;
import com.nbp.auction.exception.InvalidInputException;
import com.nbp.auction.exception.NoAuthException;
import com.nbp.auction.exception.SQLErrorException;
import com.nbp.auction.mapper.SideMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service("com.nbp.auction.service.CategoryService")
public class SideService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SideService.class);

	@Autowired
	private SideMapper sideMapper;

	public List<CategoryVO> selectCategoryList() {
		List<CategoryVO> categoryList = null;
		try {
			categoryList = sideMapper.selectCategoryList();
		} catch (DataAccessException e) {
			throw new SQLErrorException("서버 에러 입니다.");
		}
		return categoryList;
	}

	public int selectUserCoin(String userId) {
		int userCoin = 0;

		try {
			userCoin = sideMapper.selectUserCoin(userId);
		} catch (DataAccessException e) {
			throw new SQLErrorException("서버 에러 입니다.");
		}
		return userCoin;
	}

	@Transactional
	public void updateUserCoin(String userId, int coin) {
		if (coin <= 0) {
			throw new InvalidInputException("충전할 수 없는 금액입니다.");
		}
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("userId", userId);
		paramMap.put("coin", coin);

		try {
			sideMapper.updateUserCoin(paramMap);
			LOGGER.info("코인 업데이트 성공 " + userId);
		} catch (DataAccessException ex) {
			throw new SQLErrorException("서버 에러 입니다.");
		}
	}
}
