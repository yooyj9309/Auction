package com.nbp.auction.schedule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nbp.auction.service.BoardService;
import com.nbp.auction.service.TenderService;

@Component
@EnableScheduling
@Service("com.nbp.auction.service.BoardScheduler")
public class BoardScheduler {
	private static final Logger LOGGER = LoggerFactory.getLogger(BoardService.class);
	@Autowired
	TenderService tenderService;
	
	@Transactional
	@Scheduled(cron = "0 0 0 * * *")
	public void finishAuction() throws Exception {
		tenderService.finishAuction();
		LOGGER.info("UPDATE AUCTION 24:00");
	}

	
}
