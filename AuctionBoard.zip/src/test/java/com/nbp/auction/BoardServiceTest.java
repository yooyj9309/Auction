package com.nbp.auction;

import static org.junit.Assert.*;

import org.junit.Test;

public class BoardServiceTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
